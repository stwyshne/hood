//
//  Library.swift
//  MyProject
//
//  Designed in DetailsPro
//  Copyright © (My Organization). All rights reserved.
//

import SwiftUI

struct Library: View {
    var body: some View {
		// Library
		VStack {
			// Status Bar
			HStack {
				Text("9:41")
					.frame(width: 109)
					.clipped()
					.font(.system(.body, weight: .semibold))
				Spacer()
				HStack(spacing: 5) {
					Image(systemName: "cellularbars")
						.imageScale(.small)
					Image(systemName: "wifi")
						.imageScale(.small)
					Image(systemName: "battery.100")
						.symbolRenderingMode(.hierarchical)
						.font(.system(.body, weight: .light))
				}
				.frame(width: 109)
				.clipped()
				.font(.system(.body, weight: .semibold))
			}
			.padding(.vertical, 0)
			.padding()
			.frame(alignment: .top)
			.clipped()
			.frame(width: .infinity, height: .infinity, alignment: .bottom)
			.clipped()
			.background(Color(.systemBackground))
			.background {
				RoundedRectangle(cornerRadius: 4, style: .continuous)
					.fill(Color(.systemFill))
			}
			ScrollView(.horizontal) {
				VStack(spacing: 0) {
					Group {
						Text("my Library")
							.font(.system(.largeTitle, weight: .semibold))
							.frame(maxWidth: .infinity, alignment: .leading)
							.clipped()
							.padding(.leading)
						Divider()
							.padding(.top, 11)
						// Music of the Spheres
						HStack(spacing: 14) {
							// Art
							Image(uiImage: UIImage(named: "Image 1.png") ?? .init())
								.renderingMode(.original)
								.resizable()
								.aspectRatio(contentMode: .fill)
								.frame(width: 90, height: 90)
								.clipped()
								.shadow(color: Color(.sRGBLinear, red: 0/255, green: 0/255, blue: 0/255).opacity(0.25), radius: 4, x: 0, y: 2)
							// Details
							VStack(alignment: .leading, spacing: 0) {
								// Top Spacer
								Spacer()
									.frame(height: 5)
									.clipped()
								// Title
								Text("all song")
									.font(.system(.headline, weight: .medium))
								// Artist
								Text("Coldplay")
									.font(.system(.subheadline, weight: .regular))
									.foregroundStyle(.secondary)
								// Date
								Text("5 days ago")
									.font(.footnote)
									.padding(.top, 8)
									.foregroundStyle(Color(.tertiaryLabel))
							}
							Spacer()
						}
						.padding()
						Text("Arts")
						// 30
						HStack(spacing: 14) {
							// Art
							Image(uiImage: UIImage(named: "Image 6.png") ?? .init())
								.renderingMode(.original)
								.resizable()
								.aspectRatio(contentMode: .fill)
								.frame(width: 90, height: 90)
								.clipped()
								.shadow(color: Color(.sRGBLinear, red: 0/255, green: 0/255, blue: 0/255).opacity(0.25), radius: 4, x: 0, y: 2)
							// Details
							VStack(alignment: .leading, spacing: 0) {
								// Top Spacer
								Spacer()
									.frame(height: 5)
									.clipped()
								// Title
								Text(" ")
									.font(.system(.headline, weight: .medium))
								// Artist
								Text("Adele")
									.font(.system(.subheadline, weight: .regular))
									.foregroundStyle(.secondary)
								// Date
								Text("12 days ago")
									.font(.footnote)
									.padding(.top, 8)
									.foregroundStyle(Color(.tertiaryLabel))
							}
							Spacer()
						}
						.padding()
						Divider()
						// Red (Taylor’s Version)
						HStack(spacing: 14) {
							// Art
							Image(uiImage: UIImage(named: "Image 5.png") ?? .init())
								.renderingMode(.original)
								.resizable()
								.aspectRatio(contentMode: .fill)
								.frame(width: 90, height: 90)
								.clipped()
								.shadow(color: Color(.sRGBLinear, red: 0/255, green: 0/255, blue: 0/255).opacity(0.25), radius: 4, x: 0, y: 2)
							// Details
							VStack(alignment: .leading, spacing: 0) {
								// Top Spacer
								Spacer()
									.frame(height: 5)
									.clipped()
								// Title
								Text(" ")
									.font(.system(.headline, weight: .medium))
								// Artist
								Text("Taylor Swift")
									.font(.system(.subheadline, weight: .regular))
									.foregroundStyle(.secondary)
								// Date
								Text("14 days ago")
									.font(.footnote)
									.padding(.top, 8)
									.foregroundStyle(Color(.tertiaryLabel))
							}
							Spacer()
						}
						.padding()
						Divider()
						// =
						HStack(spacing: 14) {
							// Art
							Image(uiImage: UIImage(named: "Image 3.png") ?? .init())
								.renderingMode(.original)
								.resizable()
								.aspectRatio(contentMode: .fill)
								.frame(width: 90, height: 90)
								.clipped()
								.shadow(color: Color(.sRGBLinear, red: 0/255, green: 0/255, blue: 0/255).opacity(0.25), radius: 4, x: 0, y: 2)
							// Details
							VStack(alignment: .leading, spacing: 0) {
								// Top Spacer
								Spacer()
									.frame(height: 5)
									.clipped()
								// Title
								Text(" ")
									.font(.system(.headline, weight: .medium))
								// Artist
								Text("Ed Sheeran")
									.font(.system(.subheadline, weight: .regular))
									.foregroundStyle(.secondary)
								// Date
								Text("19 days ago")
									.font(.footnote)
									.padding(.top, 8)
									.foregroundStyle(Color(.tertiaryLabel))
							}
							Spacer()
						}
						.padding()
						Divider()
					}
					Group {
						Text("Load more")
							.font(.system(.subheadline))
							.padding()
							.foregroundStyle(.blue)
						Divider()
						Spacer()
							.frame(height: 40)
							.clipped()
					}
				}
				.frame(maxWidth: .infinity)
				.clipped()
				.padding(.top, 80)
			}
			// Tab Bar
			VStack(spacing: 0) {
				Divider()
				HStack(spacing: 10) {
					ForEach(0..<5) { _ in // Replace with your data model here
						VStack(spacing: 0) {
							Image(systemName: "play.circle.fill")
								.imageScale(.large)
								.frame(height: 26)
								.clipped()
							Text("Listen Now")
								.font(.caption2)
								.foregroundStyle(.primary)
						}
						.frame(maxWidth: .infinity)
						.clipped()
						.frame(height: 45)
						.clipped()
						.foregroundStyle(Color(.quaternaryLabel))
					}
				}
				.padding(.horizontal, 15)
				.padding(.top, 5)
			}
			.frame(height: 84, alignment: .top)
			.clipped()
			.background {
				Rectangle()
					.fill(.clear)
					.background(Material.bar)
			}
		}
    }
}

#Preview {
    Library()
}