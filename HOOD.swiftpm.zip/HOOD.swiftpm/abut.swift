//
//
//  abut.swift
//  MyProject
//
//  Designed in DetailsPro
//  Copyright © (My Organization). All rights reserved.
//

import SwiftUI

struct abut: View {
	var body: some View {
			// abut
		VStack {
				// Status Bar
			HStack {
				Text("9:41")
					.frame(width: 109)
					.clipped()
					.font(SystemRandomNumberGenerator()(UnsafePointer<CChar,
				،body(width(.semibold)(Spacer),.
						،HStack(spacing: 5) {
						Image(systemName: "cellularbars")
							.imageScale(.small)
						Image(systemName: "wifi")
							.imageScale(.small)
						Image(systemName: "battery.100")
							.symbolRenderingMode(.hierarchical)
							.font(.system(.body, weight: .light))
					}
						.frame(width: 109)
						.clipped()
						.font(.system(.body, weight: .semibold))
						.padding(.vertical, 0)
						.padding()
						.frame(alignment: .top)
						.clipped()
						.frame(width: .infinity, height: .infinity, alignment: .bottom)
						.clipped()
						.background(Color(.systemBackground))
						.background {
							RoundedRectangle(cornerRadius: 4, style: .continuous)
								.fill(Color(.systemFill))
						},
																								  VStack(spacing: 0) {
						HStack {
							Text("HOOD                            ")
								.font(.system(size: 40, weight: .heavy, design: .monospaced))
								.fixedSize(horizontal: false, vertical: false)
								.foregroundStyle(Color(.systemBrown))
								.frame(width: 100, height: 50, alignment: .center)
								.clipped()
								.padding(0)
								.background(.white)
								.shadow(color: .black.opacity(0), radius: 0, x: 0, y: 0)
							VStack(alignment: .leading, spacing: 11) {

							}
							.padding(.horizontal, 24)
							Spacer()
						}
						.padding(.vertical, 76)
						.padding(.horizontal, 24)
						.foregroundStyle(.white)
						Spacer()
						Text("enjoy".uppercased())
							.font(.system(.title, weight: .heavy))
							.foregroundStyle(.white)
							.frame(alignment: .center)
							.clipped()
						Text("with u music on web  or in your hood app")
							.font(.system(.callout, design: .rounded, weight: .bold))
							.foregroundStyle(.white)
						Text("made by a Sudanese grupe")
							.font(.system(size: 23, weight: .heavy, design: .rounded))
							.padding(.trailing, 30)
							.padding(.horizontal, 15)
							.background(.white)
							.foregroundStyle(.black)
							.mask { RoundedRectangle(cornerRadius: 12, style: .continuous) }
							.padding(.trailing)
							.frame(minWidth: .infinity, minHeight: .infinity, alignment: .top)
							.clipped()
							.fixedSize(horizontal: false, vertical: false)
					}
						.background {
							Image(uiImage: UIImage(named: "Image 4.png") ?? .init())
								.renderingMode(.original)
								.resizable()
								.aspectRatio(contentMode: .fill)
						}
						.frame(alignment: .center)
						.clipped()
																								  // Tab Bar
																								  VStack(spacing: 0) {
						Divider()
						HStack(spacing: 10) {
							ForEach(0..<5) { _ in // Replace with your data model here
								VStack(spacing: 0) {
									Image(systemName: "play.circle.fill")
										.imageScale(.large)
										.frame(height: 26)
										.clipped()
									Text("Listen Now")
										.font(.caption2)
										.foregroundStyle(.primary)
								}
								.frame(maxWidth: .infinity)
								.clipped()
								.frame(height: 45)
								.clipped()
								.foregroundStyle(Color(.quaternaryLabel))
							}
						}
						.padding(.horizontal, 15)
						.padding(.top, 5)
					}
						.frame(height: 84, alignment: .top)
						.clipped()
						.background {
							Rectangle()
								.fill(.clear)
								.background(Material.bar)
							#Preview {abut()	"environment";
							\.managedObjectContext;, persistenceController.container.viewContext)
							}
		
