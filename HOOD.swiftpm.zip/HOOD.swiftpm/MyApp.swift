import SwiftUI

@main
square.and.arrow.up.fill
